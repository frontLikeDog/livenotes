# -*- coding: utf-8 -*-
"""零标注兜底：没实名时，也要能给一条观点一个可指代的人。

分享卡、观点地图、圆桌摘要都需要「这句话是谁说的」。但语音厅里每天都有
新人，要求用户逐场标注不现实。这里把称呼分成三层，成本从低到高：

1. 声纹/人工确认的人：用 ``persons.name``；
2. 本场真实昵称（平台麦位名、人工改名）：原样展示，标「直播间昵称」；
3. 只有位置/聚类标签：按首次发言顺序生成「本场第 N 位上麦者」。

关键边界：fallback **只存在于展示层**，不写进 ``claims.who``。``who`` 仍然
只存可跨场比较的署名，否则两个同名陌生人会在人物档案里被合并。
"""
from __future__ import annotations

import json
import re
import sqlite3

# 位置/机器标签：这些不是名字，不能直接当「谁」展示。
_POSITIONAL_RE = re.compile(
    r"^(主播|主持人|嘉宾|说话人|用户|观众|有人|未识别|连麦|路人|网友|"
    r"聚类标签|簇|SPK[_-]?\d+)")
_ROLE_LABELS = {"主播", "主持人"}

SOURCE_LABELS = {
    "confirmed": "已确认",
    "auto": "声纹识别",
    "candidate": "疑似",
    "nickname": "直播间昵称",
    "role": "角色",
    "session": "本场编号",
    "name": "本场署名",
    "shared": "",
}


def is_positional(label: str) -> bool:
    text = str(label or "").strip()
    return bool(text and _POSITIONAL_RE.match(text))


def clean_name(label: object) -> tuple[str, str]:
    """公开的标签清理：返回 (可展示的昵称, nickname|role|session)。

    位置标签返回 ``("", "role"/"session")``，调用方应改用本场编号兜底；
    只有 ``nickname`` 才是可以落到 ``claims.who`` 的署名。
    """
    return _clean_label(label)


def _clean_label(label: object) -> tuple[str, str]:
    """把 ``主播 · 阿哲（疑似）`` 拆成可展示的昵称与来源。"""
    text = str(label or "").strip()
    if not text:
        return "", ""
    text = re.sub(r"（疑似）$", "", text).strip()
    if "·" in text:
        parts = [p.strip() for p in text.split("·") if p.strip()]
        for part in reversed(parts):
            if part and not is_positional(part):
                return part, "nickname"
        if parts and parts[0] in _ROLE_LABELS:
            return parts[0], "role"
    if is_positional(text):
        return (text, "role") if text in _ROLE_LABELS else ("", "session")
    return text, "nickname"


def roster(conn: sqlite3.Connection, sid: str) -> dict:
    """本场说话人名单，按首次发言顺序编号。

    返回 ``{"entries": [...], "by_id": {...}, "by_label": {...}}``。编号是
    本场稳定的：同一个人在同一场里永远得到同一个「第 N 位」。
    """
    rows = conn.execute(
        "SELECT u.speaker_id, MIN(u.t_start) AS first_t,"
        " MAX(s.display_name) AS display_name,"
        " MAX(u.speaker_label) AS speaker_label,"
        " MAX(s.person_id) AS person_id, MAX(s.person_state) AS person_state,"
        " MAX(p.name) AS person_name,"
        " COUNT(*) AS n_utterances,"
        " COALESCE(SUM(u.t_end-u.t_start),0) AS seconds"
        " FROM utterances u"
        " LEFT JOIN speakers s ON s.session_id=u.session_id"
        "   AND s.speaker_id=u.speaker_id"
        " LEFT JOIN persons p ON p.person_id=s.person_id"
        " WHERE u.session_id=? GROUP BY u.speaker_id"
        " ORDER BY first_t, u.speaker_id", (str(sid or ""),)).fetchall()
    entries: list[dict] = []
    by_id: dict[str, dict] = {}
    by_label: dict[str, dict] = {}
    for i, row in enumerate(rows, 1):
        speaker_id = str(row["speaker_id"] or "")
        label, label_kind = _clean_label(row["display_name"] or row["speaker_label"])
        if label_kind != "nickname":
            alt, alt_kind = _clean_label(row["speaker_label"] or "")
            if alt_kind == "nickname":
                label, label_kind = alt, alt_kind
        person_name = str(row["person_name"] or "").strip()
        state = str(row["person_state"] or "")
        if person_name and state in ("auto", "confirmed"):
            who, source = person_name, state
        elif person_name and state == "cand":
            who, source = person_name + "（疑似）", "candidate"
        elif label_kind == "nickname":
            who, source = label, "nickname"
        elif label_kind == "role":
            who, source = label, "role"
        else:
            who, source = "本场第 %d 位上麦者" % i, "session"
        entry = {
            "speaker_id": speaker_id,
            "who": who,
            "source": source,
            "source_label": SOURCE_LABELS.get(source, ""),
            "label": label,
            "person_id": str(row["person_id"] or ""),
            "person_name": person_name,
            "person_state": state,
            "first_t": row["first_t"],
            "n_utterances": int(row["n_utterances"] or 0),
            "seconds": float(row["seconds"] or 0.0),
            "ordinal": i,
        }
        entries.append(entry)
        if speaker_id:
            by_id[speaker_id] = entry
        # 旧总结/旧 claims 里可能直接存了「嘉宾1」「聚类标签 09」；这些
        # 原始标签也要能落到本场编号，否则会退化成「本场共同讨论」。
        for raw in (row["display_name"], row["speaker_label"], label, who):
            text = str(raw or "").strip()
            if text:
                by_label.setdefault(text, entry)
    return {"entries": entries, "by_id": by_id, "by_label": by_label}


def resolve(roster_map: dict, *, speaker_id: object = "", speaker_label: object = "",
            person_id: object = "", who: object = "") -> dict | None:
    """把一条观点/要点落到本场某个说话人；落不到返回 None。"""
    if not roster_map:
        return None
    pid = str(person_id or "").strip()
    if pid:
        for entry in roster_map.get("entries") or []:
            if entry.get("person_id") == pid:
                return entry
    sid = str(speaker_id or "").strip()
    if sid and sid in (roster_map.get("by_id") or {}):
        return roster_map["by_id"][sid]
    for candidate in (speaker_label, who):
        text = str(candidate or "").strip()
        if not text:
            continue
        hit = (roster_map.get("by_label") or {}).get(text)
        if hit:
            return hit
        cleaned, kind = _clean_label(text)
        if cleaned:
            hit = (roster_map.get("by_label") or {}).get(cleaned)
            if hit:
                return hit
        if kind == "nickname" and cleaned:
            # 有昵称但不在本场 roster 里（老总结/手工数据）：仍然可用作署名。
            return {"who": cleaned, "source": "name",
                    "source_label": SOURCE_LABELS["name"], "speaker_id": "",
                    "label": cleaned, "person_id": "", "person_name": "",
                    "person_state": "", "first_t": None, "seconds": 0.0,
                    "ordinal": 0}
        if not is_positional(text):
            return {"who": text, "source": "name",
                    "source_label": SOURCE_LABELS["name"], "speaker_id": "",
                    "label": text, "person_id": "", "person_name": "",
                    "person_state": "", "first_t": None, "seconds": 0.0,
                    "ordinal": 0}
    return None


def _evidence(row: dict) -> list[dict]:
    raw = row.get("evidence_json")
    if isinstance(raw, list):
        return [e for e in raw if isinstance(e, dict)]
    try:
        data = json.loads(str(raw or "[]"))
    except (TypeError, ValueError):
        return []
    return [e for e in data if isinstance(e, dict)]


def claim_ref(row: dict, roster_map: dict) -> dict:
    """一条 claims 行的展示身份。优先 person_id，其次证据里的 speaker_id。"""
    direct = resolve(roster_map, person_id=row.get("person_id"), who=row.get("who"))
    if direct and direct.get("source") != "name":
        return direct
    for ev in _evidence(row):
        hit = resolve(roster_map,
                      speaker_id=ev.get("speaker_id"),
                      speaker_label=ev.get("speaker") or ev.get("speaker_label"),
                      who=row.get("who"))
        if hit:
            return hit
    return direct or {"who": "一位上麦者", "source": "shared",
                      "source_label": "", "speaker_id": "", "label": "",
                      "person_id": "", "person_name": "", "person_state": "",
                      "first_t": None, "seconds": 0.0, "ordinal": 0}


def point_ref(point: dict, roster_map: dict) -> dict:
    """总结要点（notes 的 point dict）的展示身份。"""
    direct = resolve(roster_map, who=point.get("claim_speaker"))
    if direct and direct.get("source") != "name":
        return direct
    for ev in (point.get("evidence") or []):
        if not isinstance(ev, dict):
            continue
        hit = resolve(roster_map,
                      speaker_id=ev.get("speaker_id"),
                      speaker_label=ev.get("speaker") or ev.get("speaker_label"),
                      who=point.get("claim_speaker"))
        if hit:
            return hit
    return direct or {"who": "", "source": "shared", "source_label": "",
                      "speaker_id": "", "label": "", "person_id": "",
                      "person_name": "", "person_state": "",
                      "first_t": None, "seconds": 0.0, "ordinal": 0}

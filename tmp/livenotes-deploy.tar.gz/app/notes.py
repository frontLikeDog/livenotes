# -*- coding: utf-8 -*-
"""笔记聚合与检索索引。

P1 的「笔记页」不是一个新存储：总结、高光、书签、逐字稿都已经在库里，
这里只做三件事：

1. ``build_note``：把一场的所有可用内容聚成一个前端能直接渲染的结构；
2. ``derive_state``：没有 ``notes`` 行的历史场次也能给出状态；
3. ``index_session``：把总结/要点/高光/书签写进 ``note_units``，
   全库搜索和问笔记共用这一份索引。
"""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timedelta
from typing import Any

from . import claims, identity, shape, store


# 分组展示顺序：主持先说、主讲其次，提问和上麦跟在后面，认不出的一起放最后。
ROLE_ORDER = {"host": 0, "speaker": 1, "guest": 2, "asker": 3, "shared": 4}


def _summary(conn: sqlite3.Connection, sid: str) -> dict:
    row = store.latest_summary(conn, sid, "content")
    if not row:
        row = conn.execute(
            "SELECT payload_json,engine FROM summaries WHERE session_id=? "
            "ORDER BY created_at DESC, id DESC LIMIT 1", (sid,)).fetchone()
        if not row:
            return {}
        try:
            payload = json.loads(row["payload_json"] or "{}")
        except (TypeError, ValueError):
            return {}
        # 老 payload 没有 engine_kind，也没有排序：统一在读取边界补上。
        payload = store.normalize_summary_payload(payload, str(row["engine"] or ""))
        return payload if isinstance(payload, dict) else {}
    payload = row.get("payload") or {}
    return payload if isinstance(payload, dict) else {}


def _speaker_names(conn: sqlite3.Connection, sid: str) -> dict[str, str]:
    return {str(r["speaker_id"]): str(r["display_name"] or r["speaker_id"])
            for r in conn.execute(
                "SELECT speaker_id,display_name FROM speakers WHERE session_id=?",
                (sid,))}


def _duration(conn: sqlite3.Connection, sid: str) -> float:
    row = conn.execute("SELECT COALESCE(MAX(t_end),0) AS t FROM utterances "
                       "WHERE session_id=?", (sid,)).fetchone()
    return float(row["t"] or 0) if row else 0.0


def bookmarks(conn: sqlite3.Connection, sid: str) -> list[dict]:
    """书签 = marks（全部）+ 人工/实时收藏的高光，按时间排序去重。"""
    out: list[dict] = []
    for r in conn.execute(
            "SELECT id,t,note,kind,created_at FROM marks WHERE session_id=? "
            "ORDER BY t", (sid,)):
        out.append({"id": "m%d" % int(r["id"]), "ref_id": str(r["id"]),
                    "t": float(r["t"] or 0), "note": str(r["note"] or ""),
                    "kind": str(r["kind"] or "mark"),
                    "source": "recording" if str(r["kind"] or "") != "bookmark"
                    else "reader",
                    "created_at": r["created_at"]})
    for r in conn.execute(
            "SELECT id,t_start,peak_t,text,quote,hook,kind,source,speaker_label "
            "FROM highlights WHERE session_id=? "
            "AND (kind='manual' OR source IN ('manual','live')) "
            "ORDER BY peak_t", (sid,)):
        t = float(r["peak_t"] or r["t_start"] or 0)
        if any(abs(float(b["t"]) - t) < 0.5 for b in out if b["kind"] != "mark"):
            continue
        out.append({"id": "h%d" % int(r["id"]), "ref_id": str(r["id"]),
                    "t": t, "note": str(r["quote"] or r["hook"] or r["text"] or ""),
                    "kind": "highlight", "source": str(r["source"] or "manual"),
                    "speaker": str(r["speaker_label"] or ""),
                    "created_at": ""})
    out.sort(key=lambda x: float(x.get("t") or 0))
    return out


def build_note(conn: sqlite3.Connection, sid: str) -> dict:
    """一场笔记的完整聚合。不存在返回 ``{"ok": False}``。"""
    s = store.get_session(conn, sid)
    if not s or s.get("deleted_at"):
        return {"ok": False, "error": "这篇笔记不存在"}
    summary = _summary(conn, sid)
    note = store.get_note(conn, sid)
    state, progress = store.derive_note_state(conn, sid, note)
    run = store.get_active_run(conn, sid)
    if run and state not in ("ready", "partial"):
        state = "running" if run.get("status") == "running" else "queued"
        progress = int(run.get("progress") or progress or 0)
    names = _speaker_names(conn, sid)
    host_id = str(summary.get("host_speaker") or "")
    streamer = names.get(host_id, "") if host_id else ""
    if not streamer:
        first = conn.execute(
            "SELECT display_name FROM speakers WHERE session_id=? "
            "ORDER BY speaker_id LIMIT 1", (sid,)).fetchone()
        streamer = str(first["display_name"] or "") if first else ""
    highlights = store.list_highlights(conn, sid, 20)
    # 收藏的排前面（先给人自己留的），再按分数。来源仍用 source 标明。
    highlights.sort(key=lambda h: (0 if str(h.get("source") or "") in
                                   ("manual", "live") else 1,
                                   -float(h.get("score") or 0)))
    marks = bookmarks(conn, sid)
    speakers = []
    for r in conn.execute(
            "SELECT sp.speaker_id, sp.display_name, COUNT(u.id) AS n, "
            "COALESCE(SUM(u.t_end-u.t_start),0) AS secs "
            "FROM speakers sp LEFT JOIN utterances u ON u.session_id=sp.session_id "
            "AND u.speaker_id=sp.speaker_id WHERE sp.session_id=? "
            "GROUP BY sp.speaker_id ORDER BY secs DESC", (sid,)):
        speakers.append({"speaker_id": r["speaker_id"],
                         "label": r["display_name"] or r["speaker_id"],
                         "n": int(r["n"] or 0),
                         "seconds": round(float(r["secs"] or 0), 1)})
    points = []
    roster = identity.roster(conn, sid)
    # 笔记页的序号也按时间排：同一场先讲什么、后讲什么，读者要能顺着看下来。
    summary_points = sorted(
        summary.get("points") or [],
        key=lambda p: (p.get("t_from") is None, p.get("t_from") or 0))
    for i, p in enumerate(summary_points):
        ev = p.get("evidence") or []
        quote = ""
        if ev:
            quote = str(ev[0].get("text") or "")[:160]
        ref = identity.point_ref(p, roster)
        raw_who = str(p.get("claim_speaker") or "").strip()
        clean_who, who_kind = identity.clean_name(raw_who)
        if who_kind != "nickname":
            clean_who = ""
        points.append({
            "i": i, "title": str(p.get("title") or ""),
            "gist": str(p.get("gist") or ""),
            "t_from": p.get("t_from"), "t_to": p.get("t_to"),
            "quote": quote, "speakers": p.get("speakers") or [],
            # 位置标签不落成跨场署名；展示用下面的 claim_speaker_label。
            "claim_speaker": clean_who,
            # 零标注兜底：claim_speaker 为空时，仍然给这条要点一个本场指代。
            "claim_speaker_label": str(ref.get("who") or ""),
            "claim_speaker_source": str(ref.get("source") or ""),
            "claim_speaker_speaker_id": str(ref.get("speaker_id") or ""),
            "stance": str(p.get("stance") or ""),
            # 跨场视图（「这个主题他讲过几场」）靠主题对齐，而不是靠标题文案。
            "topic": claims.point_topic(p),
            "evidence": [{"id": e.get("id"), "t": e.get("t_start"),
                          "text": str(e.get("text") or "")[:200],
                          "speaker": e.get("speaker_label") or "",
                          "speaker_id": e.get("speaker_id") or "",
                          # 类别留着：判断「这条是提问还是主张」要用，
                          # 观点地图靠它挑出「没人回答的问题」。
                          "category": e.get("category") or ""}
                         for e in ev[:4]],
        })
    generated_at = (note or {}).get("generated_at") or summary.get("generated_at") \
        or (s.get("started_at") or "")
    shape_info = _shape_info(conn, sid, summary)
    names_by_label = {}
    for sp in speakers:
        names_by_label.setdefault(str(sp["label"]), sp["speaker_id"])
    by_speaker = _group_points(points, shape_info, names_by_label)
    _attach_history(conn, points)
    opinion_map = _opinion_map(points, shape_info, names_by_label)
    # 主持的显示名：形态层判出来的主持优先，其次是模型认的主讲人。
    host_id = str(shape_info.get("host_id") or "")
    host_label = names.get(host_id, "") if host_id else ""
    streamer = streamer or host_label
    rel = _related(conn, sid, summary.get("topics") or [], streamer)
    return {
        "ok": True,
        "session": {"session_id": sid, "title": summary.get("session_title")
                    or s.get("title") or "未命名直播",
                    "started_at": s.get("started_at") or "",
                    "duration_s": float(s.get("duration_s") or _duration(conn, sid)),
                    "source_mode": s.get("source_mode") or "",
                    "audio_state": "ready" if s.get("audio_path") else "none"},
        "note_state": state, "progress": progress,
        "note": note or {},
        "summary": {"overview": summary.get("overview") or "",
                    "topics": summary.get("topics") or [],
                    "engine": summary.get("engine") or "",
                    "engine_kind": summary.get("engine_kind") or "",
                    "engine_model": summary.get("engine_model") or "",
                    "engine_reason": summary.get("engine_reason") or "",
                    "generated_at": summary.get("generated_at") or "",
                    "caveats": summary.get("caveats") or [],
                    "stats": summary.get("stats") or {}},
        "streamer": streamer, "host": host_label or streamer,
        "shape": shape_info, "points": points, "by_speaker": by_speaker,
        "opinion_map": opinion_map,
        "highlights": highlights, "bookmarks": marks,
        "speakers": speakers, "generated_at": generated_at,
        "related": rel,
        "counts": {"points": len(points), "highlights": len(highlights),
                   "bookmarks": len(marks), "speakers": len(speakers)},
    }


def _shape_info(conn: sqlite3.Connection, sid: str, summary: dict) -> dict:
    """形态优先用总结里存的那份（跟要点同一批输入）；老总结没有就现算。"""
    saved = summary.get("shape")
    if isinstance(saved, dict) and saved.get("kind"):
        return saved
    return shape.session_shape(conn, sid)


def _group_points(points: list[dict], shape_info: dict,
                  names_by_label: dict[str, str]) -> list[dict]:
    """按「谁提的」重排要点，供笔记页的观点分组。

    - 归属来自 ``claim_speaker``（标签）；认不出的人归到「本场共同讨论」，
      且只在圆桌/问答里才单列，单人场不需要多一层。
    - 角色取自 ``shape``（主持 / 主讲 / 提问 / 上麦），只影响展示顺序与徽标。
    - 组内按时间排序，组间按「实质发言量」排，主讲在前。
    """
    if not points:
        return []
    roles = (shape_info or {}).get("roles") or {}
    buckets: dict[str, list[dict]] = {}
    for p in points:
        # claim_speaker 是落库署名（可能为空）；为空时用本场兜底指代分组，
        # 这样不会把三四个没名字的人合成一坨「本场共同讨论」。
        key = str(p.get("claim_speaker") or p.get("claim_speaker_label") or "").strip()
        buckets.setdefault(key, []).append(p)

    out: list[dict] = []
    for who, items in buckets.items():
        items.sort(key=lambda p: (p.get("t_from") is None, p.get("t_from") or 0))
        sid = next((str(p.get("claim_speaker_speaker_id") or "") for p in items
                    if p.get("claim_speaker_speaker_id")), "")
        if not sid and who:
            sid = names_by_label.get(who, "")
        role = (roles.get(sid) or {}) if sid else {}
        label = str(role.get("label") or "")
        out.append({
            "who": who or "本场共同讨论",
            "speaker_id": sid,
            "role": str(role.get("role") or ("shared" if not who else "")),
            "role_label": label,
            "seconds": float(role.get("seconds") or 0.0),
            "points": items,
        })

    def _rank(group: dict) -> tuple:
        role = group.get("role") or ""
        return (ROLE_ORDER.get(role, len(ROLE_ORDER)),
                -float(group.get("seconds") or 0.0),
                0 if group.get("points") else 1,
                str(group.get("who") or ""))

    out.sort(key=_rank)
    return out


def _attach_history(conn: sqlite3.Connection, points: list[dict]) -> None:
    """给每个「人 × 主题」标上「这个主题他还在别的几场讲过」。

    只在跨场时才标：只出现在这一场的观点不需要多一个徽标。人用本场署名
    （``claim_speaker``），和 ``claims.who`` 的存法一一对应；按人分组和
    观点地图读的是同一批 point 对象，写一次两边都有。
    """
    if not points:
        return
    keys: set[str] = set()
    topics: set[str] = set()
    for p in points:
        key = claims.person_key("", p.get("claim_speaker") or "")
        topic = str(p.get("topic") or "").strip()
        if key and topic:
            keys.add(key)
            topics.add(topic)
    if not keys:
        return
    hist = claims.history_index(conn, keys, topics)
    for p in points:
        key = claims.person_key("", p.get("claim_speaker") or "")
        info = hist.get((key, str(p.get("topic") or "").strip()))
        p["cross_sessions"] = int(info["n_sessions"]) if info else 1


def _opinion_map(points: list[dict], shape_info: dict,
                 names_by_label: dict[str, str]) -> dict:
    """本场的观点地图：按主题排，一个人一行，标出明确的分歧与无人回答的问题。

    和「按人分组」互补：按人回答「他讲了什么」，按主题回答「**这场有几种
    观点、谁和谁冲突、哪个问题没人答**」（docs/41 §3.5）。仍然只在已有要点
    上做聚合，不新增模型调用、不推断谁对谁错。
    """
    if not points:
        return {"topics": [], "open_questions": [], "stats": {}}
    roles = (shape_info or {}).get("roles") or {}
    by_topic: dict[str, list[dict]] = {}
    for p in points:
        by_topic.setdefault(claims.topic_label(p.get("topic") or ""), []).append(p)

    topics: list[dict] = []
    open_questions: list[dict] = []
    n_conflicts = 0
    for label, items in by_topic.items():
        items.sort(key=lambda p: (p.get("t_from") is None, p.get("t_from") or 0))
        kinds = [claims.point_kind(p) for p in items]
        # 一个主题下全是提问、没有一条主张：这场没答上来，单列到「还没答案」。
        if items and all(k == "question" for k in kinds):
            for p in items[:3]:
                src = next((e for e in p.get("evidence") or []
                            if str(e.get("category") or "") == "question_consult"),
                           (p.get("evidence") or [{}])[0])
                open_questions.append({
                    "text": str(p.get("stance") or p.get("title") or "")[:80],
                    "who": str(p.get("claim_speaker")
                               or p.get("claim_speaker_label") or ""),
                    "t": src.get("t"), "quote": str(src.get("text") or "")[:120]})
            continue

        # 同一个主题下一个人只说一次：取他最早的那条，后面同人的并进来。
        entries: dict[str, dict] = {}
        for p, kind in zip(items, kinds):
            if kind == "question":
                continue
            who = str(p.get("claim_speaker")
                      or p.get("claim_speaker_label") or "").strip()
            if who in entries:
                entries[who]["n"] += 1
                continue
            sid = str(p.get("claim_speaker_speaker_id") or "")
            if not sid and who:
                sid = names_by_label.get(who, "")
            role = (roles.get(sid) or {}) if sid else {}
            text = str(p.get("stance") or p.get("quote") or "")
            source = str(p.get("claim_speaker_source") or "")
            entries[who] = {
                "who": who or "本场共同讨论",
                "who_source": source,
                "who_source_label": identity.SOURCE_LABELS.get(source, ""),
                "speaker_id": sid,
                "role": str(role.get("role") or ""),
                "role_label": str(role.get("label") or ""),
                "stance": str(p.get("stance") or p.get("title") or ""),
                "gist": str(p.get("gist") or ""),
                "quote": str(p.get("quote") or ""),
                "t": p.get("t_from"), "n": 1,
                "cross_sessions": int(p.get("cross_sessions") or 1),
                # 只在原话里真出现了反对词时才标：说法不同 ≠ 反对。
                "disagree": claims.disagrees(text),
                "vs": "",
            }
        rows = [e for e in entries.values() if e["who"]]
        if not rows:
            continue
        # 「和谁冲突」：反对的那位指向他前面最近的一个不同的人。
        prev = ""
        for e in rows:
            if e["disagree"] and prev and prev != e["who"]:
                e["vs"] = prev
                n_conflicts += 1
            prev = e["who"]
        conflict = bool(n_conflicts and any(e["vs"] for e in rows))
        # 组内按时间排，观众顺着听下来就是顺着看下来。
        rows.sort(key=lambda e: (e["t"] is None, e["t"] or 0))
        topics.append({"topic": label, "label": label, "n": len(items),
                       "n_people": len(rows), "conflict": conflict,
                       "t_from": items[0].get("t_from"), "entries": rows})

    # 主题按出现先后排；「其他」永远最后（它不是主题，是没归类的兜底）。
    topics.sort(key=lambda g: (g["label"] == claims.GENERIC_LABEL,
                               g["t_from"] is None, g["t_from"] or 0))
    return {
        "topics": topics,
        "open_questions": open_questions[:3],
        "stats": {"topics": len(topics),
                  "people": len({e["who"] for g in topics for e in g["entries"]}),
                  "conflicts": len([g for g in topics if g["conflict"]]),
                  "open_questions": len(open_questions)},
    }


def _related(conn: sqlite3.Connection, sid: str, topics: list[str],
             streamer: str, limit: int = 4) -> list[dict]:
    """同主播 / 同主题的最近场次。规则匹配，够用且不花模型钱。"""
    out: list[dict] = []
    rows = [dict(r) for r in conn.execute(
        "SELECT s.id,s.title,s.started_at,s.duration_s,"
        " (SELECT payload_json FROM summaries su WHERE su.session_id=s.id "
        "  ORDER BY su.created_at DESC, su.id DESC LIMIT 1) AS payload_json "
        "FROM sessions s WHERE s.id<>? AND s.deleted_at IS NULL "
        "ORDER BY s.started_at DESC LIMIT 30", (sid,))]
    topic_set = {str(t) for t in topics if t}
    for r in rows:
        payload = {}
        try:
            payload = json.loads(r.pop("payload_json") or "{}")
        except (TypeError, ValueError):
            payload = {}
        same_host = bool(streamer and payload.get("host_name") == streamer)
        common = topic_set & {str(t) for t in (payload.get("topics") or [])}
        if not same_host and not common:
            continue
        out.append({"session_id": r["id"],
                    "title": payload.get("session_title") or r["title"],
                    "started_at": r["started_at"],
                    "duration_s": float(r["duration_s"] or 0),
                    "reason": "同一个主播" if same_host else
                    ("、".join(sorted(common)[:2]) if common else "相关")})
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------- 索引

def _point_text(p: dict) -> str:
    bits = [str(p.get("title") or ""), str(p.get("gist") or "")]
    for e in (p.get("evidence") or [])[:2]:
        bits.append(str(e.get("text") or ""))
    return " ".join(b for b in bits if b).strip()


def index_session(conn: sqlite3.Connection, sid: str) -> int:
    """重建一场的 note_units。没有总结也索引书签/高光，问笔记至少能找到原话。"""
    s = store.get_session(conn, sid)
    if not s:
        return 0
    summary = _summary(conn, sid)
    title = str(summary.get("session_title") or s.get("title") or "")
    units: list[dict] = []
    if summary.get("overview"):
        units.append({"kind": "summary", "ref_id": "overview", "t": None,
                      "title": title, "text": str(summary["overview"])[:1000],
                      "weight": 0.7})
    roster = identity.roster(conn, sid)
    for i, p in enumerate(summary.get("points") or []):
        text = _point_text(p)
        if not text:
            continue
        ref = identity.point_ref(p, roster)
        units.append({"kind": "point", "ref_id": str(i),
                      "t": p.get("t_from"), "title": title, "text": text,
                      # 署名优先给归属的人，而不是「这场出现过谁」：问「阿哲怎么看 X」
                      # 要能召回他提的那条，而不是同一段里他也出过声的那条。
                      # 没实名时用「本场第 N 位」兜底，而不是留空。
                      "speaker": (str(ref.get("who") or "")
                                  or "、".join((p.get("speakers") or [])[:2])),
                      "weight": 1.0})
    for h in store.list_highlights(conn, sid, 50):
        quote = str(h.get("quote") or h.get("hook") or h.get("text") or "").strip()
        if not quote:
            continue
        units.append({"kind": "highlight", "ref_id": str(h.get("id") or ""),
                      "t": h.get("peak_t") or h.get("t_start"),
                      "speaker": str(h.get("speaker_label") or ""),
                      "title": title, "text": quote[:800], "weight": 0.9})
    for b in bookmarks(conn, sid):
        note = str(b.get("note") or "").strip()
        if not note:
            continue
        units.append({"kind": "bookmark", "ref_id": str(b.get("ref_id") or ""),
                      "t": b.get("t"), "title": title,
                      "text": note[:500], "weight": 0.8})
    n = store.replace_note_units(conn, sid, units)
    # 观点档案跟着索引一起重建：两者都只依赖这一场的总结与身份。
    try:
        claims.rebuild_session(conn, sid)
        # 身份（person_id）变化后，观点档案的分组键也要跟着更新：同一个人
        # 换了 person_id，跨场「这个主题他讲过几场」必须重算，否则人物页会漏。
    except Exception:
        import traceback
        traceback.print_exc()
    if summary:
        state = "ready" if (summary.get("overview") or summary.get("points")) else "partial"
        store.upsert_note(conn, sid, state=state, progress=100,
                          generated_at=summary.get("generated_at") or store.now())
    return n


def ensure_index(conn: sqlite3.Connection, limit: int = 0,
                 rebuild: bool = False) -> int:
    """启动时补索引：有总结但 note_units 为空（或要求全量重建）的场次。"""
    if rebuild:
        rows = conn.execute("SELECT id FROM sessions WHERE deleted_at IS NULL "
                            "ORDER BY started_at DESC").fetchall()
    else:
        rows = conn.execute(
            "SELECT s.id FROM sessions s WHERE s.deleted_at IS NULL AND EXISTS("
            "SELECT 1 FROM summaries su WHERE su.session_id=s.id) AND NOT EXISTS("
            "SELECT 1 FROM note_units nu WHERE nu.session_id=s.id) "
            "ORDER BY s.started_at DESC" +
            (" LIMIT %d" % int(limit) if limit else "")).fetchall()
    n = 0
    for r in rows:
        try:
            index_session(conn, r["id"])
            n += 1
        except Exception:
            continue
    return n


def suggest_questions(conn: sqlite3.Connection, sid: str = "",
                      limit: int = 3) -> list[str]:
    """空态建议问题。规则拼接，不调模型。"""
    if sid:
        summary = _summary(conn, sid)
        topics = [str(t) for t in (summary.get("topics") or []) if t][:3]
        title = str(summary.get("session_title") or "")
        out = []
        if topics:
            out.append("这场的%s讲了哪些关键结论？" % topics[0])
            if len(topics) > 1:
                out.append("%s和%s之间有什么关系？" % (topics[0], topics[1]))
        if title:
            out.append("《%s》最值得回听的是哪一段？" % title[:20])
        return out[:limit]
    rows = [dict(r) for r in conn.execute(
        "SELECT payload_json FROM summaries WHERE payload_json<>'' "
        "ORDER BY created_at DESC, id DESC LIMIT 8")]
    topics: list[str] = []
    for r in rows:
        try:
            data = json.loads(r["payload_json"] or "{}")
        except (TypeError, ValueError):
            continue
        for t in data.get("topics") or []:
            t = str(t).strip()
            if t and t not in topics:
                topics.append(t)
        if len(topics) >= 4:
            break
    out = []
    if topics:
        out.append("最近关于「%s」有哪些值得回看的观点？" % topics[0])
        if len(topics) > 1:
            out.append("「%s」和「%s」可以怎么结合？" % (topics[0], topics[1]))
    out.append("上周记录里最值得回听的三段是什么？")
    return out[:limit]


# ---------------------------------------------------------------- 时间范围

_CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
           "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def parse_time_scope(text: str, now: datetime | None = None) -> dict:
    """从问题里解析时间范围。识别不了返回空 dict（= 全部）。

    只覆盖常见说法；解析错了比不解析更糟，所以拿不准就返回空。
    """
    t = str(text or "")
    now = now or datetime.now()
    day = datetime(now.year, now.month, now.day)
    monday = day - timedelta(days=day.weekday())

    def _out(since: datetime, until: datetime) -> dict:
        return {"since": since.isoformat(timespec="seconds"),
                "until": until.isoformat(timespec="seconds")}

    if re.search(r"上周|上个星期|上一周", t):
        return _out(monday - timedelta(days=7), monday)
    if re.search(r"这周|本周|这个星期", t):
        return _out(monday, monday + timedelta(days=7))
    if re.search(r"上个月|上月", t):
        first = day.replace(day=1)
        prev = (first - timedelta(days=1)).replace(day=1)
        return _out(prev, first)
    m = re.search(r"最近\s*([一二两三四五六七八九十\d]+)\s*天", t)
    if m:
        raw = m.group(1)
        n = _CN_NUM.get(raw) or (int(raw) if raw.isdigit() else 0)
        if n:
            return _out(day - timedelta(days=n), day + timedelta(days=1))
    m = re.search(r"(\d{1,2})\s*月", t)
    if m:
        month = int(m.group(1))
        if 1 <= month <= 12:
            year = now.year if month <= now.month else now.year - 1
            start = datetime(year, month, 1)
            end = datetime(year + (month == 12), (month % 12) + 1, 1)
            return _out(start, end)
    if re.search(r"今年", t):
        return _out(datetime(now.year, 1, 1), datetime(now.year + 1, 1, 1))
    return {}


def scope_label(scope: dict) -> str:
    since, until = scope.get("since"), scope.get("until")
    if not since:
        return "全部笔记"
    return "%s 至 %s" % (str(since)[:10], str(until or "")[:10])
